<?php
include 'connect.php';

    $fname=$_POST['fnames'];
    $email=$_POST['em'];
    $address=$_POST['add'];
    $city=$_POST['cityy'];
    $state=$_POST['stat'];
    $zipc=$_POST['zip'];
    $noc=$_POST['cardsname'];
    $ccn=$_POST['cardsnumber'];
    $expmonth=$_POST['expsmonth'];
    $expyear=$_POST['expsyear'];


         $c->query("insert into janvi values('$fname','$email','$address','$city','$state','$zipc','$noc','$ccn','$expmonth','$expyear')"); 
?>