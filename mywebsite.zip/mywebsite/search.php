<!DOCTYPE html>
<html lang="en">
<head><title>search</title></head>
<body>
                <div class="container">
                <?php 
                $a= $_GET["search"];

                    switch($a)
                    {
                        case 'men':
                        case 'gents':include("men.php");
                        break;

                        case 'women':
                        case 'ladies':include("women.php");
                        break;

                        case 'kids':
                        case 'child':include("kids.php");
                        break;

                        default: echo"Enter correct value";
                    }
                ?>
                
</body>
</html>
