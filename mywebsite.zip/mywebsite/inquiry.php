<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        *body{
            margin: 0;
            padding:0;
            box-sizing: border-box;
  	        font-family:"Josefin Sans", sans-serif;
            font-size: 16px;
        }
 .checkout{
  	width: 500px;
 
  	background-color: #ffffff;
  	box-shadow: 0 0 9px 0 rgba(0, 0, 0, 0.3);
  	margin: 100px auto;
        }
 .checkout h1{
    text-align: center;
  	color: black;
  	font-size: 24px;
  	padding: 20px 0 20px 0;
      background-color: rgb(140, 131, 140);
  	border-bottom: 1px solid #dee0e4;

 }
 .checkout form {
  	display: flex;
  	flex-wrap: wrap;
  	justify-content: center;
  	padding-top: 20px;
}



.checkout form input[type="address"] {
  	width: 310px;
  	height: 30px;
  	border: 1px solid  rgb(140, 131, 140);
  	margin-bottom: 20px;
  	padding: 0 15px;
}
.checkout form input[type="phone_number"] {
  	width: 310px;
  	height: 30px;
  	border: 1px solid  rgb(140, 131, 140);
  	margin-bottom: 20px;
  	padding: 0 15px;
}
.checkout form input[type="submit"] {
  	width: 100%;
  	padding: 15px;
 	margin-top: 20px;
  	background-color: rgb(140, 131, 140);
  	border: 0;
  	cursor: pointer;
  	font-weight: bold;
  	color:black;
  	transition:  0.2s;
}


    </style>
</head>

<body>
<div class="checkout">
			<h1>Checkout</h1>
			<form action="connect.php" method="post">
				<label for="username">
					<i class="fas fa-user"></i>
				</label>
            <input type="text" name="username" placeholder="Username" id="username" required>


                <label for="address">
					<i class="fas fa-lock"></i>
				</label>
				<input type="address" name="address" placeholder="Address" id="address" required>

                <label for="phone_number">
					<i class="fas fa-lock"></i>
				</label>
				<input type="phone_number" name="phone_number" placeholder="Phone_number" id="phone number" required>
                
				<input type="submit" value="Checkout">
			</form>
		</div>
   

</body>
</html>