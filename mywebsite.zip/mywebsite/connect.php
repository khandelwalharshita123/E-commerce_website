 <?$l="localhost";
 $u="root";
 $p="";
 $d="ecommerce";
 $c=new mysqli($l,$u,$p,$d);

 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>thank you</title>
   
   <style>
        body{
            width: 400px;
            height:400px;
  	background-color: #ffffff;
  	box-shadow: 0 0 9px 0 black ;
   	margin: 100px auto;
    
        }
        h1{
padding-left:19px;
padding-top:15%;
        }
        h2{
            padding-left:13%;
        
        }
        .btnone {
  background: #a4a9a8;
 text-decoration:none;
  color: #000;
  
}
#myVideo {
  position: fixed;
  right: 0;
  bottom: 0;
  min-width: 100%; 
  min-height: 100%;
}

    
        </style>
</head>
<body>

  

    <container>
        
        <div class="rand_number">
             <h1>Thank you for your order<h1>
            <h2>Your order number : <?php echo(rand(11111,99999));?><h2>
            <a href="index.php" class="btnone" >Home</a>   
        </div>
    </container>
</body>
</html>


