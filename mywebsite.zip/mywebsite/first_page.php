<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>!Website</title>
	<link rel="stylesheet" type="text/css" href="login.css">
	<link href="https://fonts.googleapis.com/css?family=Josefin+Sans&display=swap" rel="stylesheet">
</head>
<body style="background-color:  rgb(140, 131, 140");>
<header>
	<main>
		<section>
			<h3>Welcome To Happy Shopping</h3>
			<h1>DO COME & SHOP <span class="change_content"> </span> <span style="margin-top: -10px;">  </span> </h1>
			<p>"Your Only Best Shopping Destination"</p>
			<a href="loginpage.php" class="btnone" >login</a>
			<a href="sigin-up.php" class="btnone" >sign-up</a>

		
		</section>
	</main>
</header>

</body>
</html>