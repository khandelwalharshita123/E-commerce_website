<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>E-commerce WEBSITE</title>
    <link href="style.css"rel="stylesheet">
    <link rel="stylesheet"href="https://cdn.jsdelivr.net/npm/swiper@8/swiper-bundle.min.css"/>
   
</head>
<body>
<div class="contain">
              
    

  
    <nav class="navbar " style="position:sticky;top:0;background: rgb(140, 131, 140);">
        <div class="nav">
            <img src="logos.png" class="brand-logo" alt="">

            <div class="nav-items">
                <div class="container">
                    <li class="link-item"><a href="women.php" class="link">Women</a></li>
                    <li class="link-item"><a href="men.php" class="link">Men</a></li>
                    <li class="link-item"><a href="kids.php" class="link">Kids</a></li>
                </div>
                <div class="search">
                <form action="search.php" method="get">
                    <input type="search" name="search" class="#search-box" placeholder="search brand, product" arial-lable="search">
                    <button class="#search-btn">search</button>
                </div>

              

                <a href="#"><img src="cartt.png" alt=""></a>
            </div>

        </div>
    </nav>
    <div class="container1">
        <div class="swiper">
            <!-- Additional required wrapper -->
            <div class="swiper-wrapper">
                <div class="swiper-slide"><img src="slide-2.jpg"></div>
                <div class="swiper-slide"><img src="women_pamplet.jpg"></div>
                <div class="swiper-slide"><img src="kids_pamplet.jpg"></div>
              

            </div>
            <!-- If we need pagination -->
            <div class="swiper-pagination"></div>

            <!-- If we need navigation buttons
            <div class="swiper-button-prev"></div>
            <div class="swiper-button-next"></div>
 -->

        </div>
    </div>
    <h1>TOP CATEGORIES</h1>
  <div class="container2">


    <div class="box">
        <a href="men.php">
     <img src="mens.jpg">Men
        </a>
    </div>

    <div class="box">
        <a href="women.php">
     <img src="women.jpg">Women
    </a>
    </div>

    <div class="box">
        <a href="kids.php">
     <img src="kid6.jpg">Kids
    </a>
    </div>
    <div class="box">
        <a href="shoe.php">
     <img src="shoes.jpg">Shoes</a>
    </div>
    <div class="box">
        <a href="heelphp.php">
     <img src="heels.jpg">Heels</a>
    </div>
    </div>
    


    <script src="https://cdn.jsdelivr.net/npm/swiper@8/swiper-bundle.min.js"></script>
    <script>
        const swiper = new Swiper('.swiper', {
            autoplay: {
                delay: 2000,
                disableOnInteraction: false,
            },

            pagination: {
                el: '.swiper-pagination',
                clickable: true
            },

            // Navigation arrows
            navigation: {
                nextEl: '.swiper-button-next',
                prevEl: '.swiper-button-prev',
            },


        });
    </script>
    <script src="https://kit.fontawesome.com/3b35a3dea4.js" crossorigin="anonymous"></script>
     <div class="about">
        <div class="boxs">
                 <h2>ABOUT</h2>
                 <h3>Contact us</h3>
                 <h3>About us</h3>
                 <h3>Careers</h3>
                 <h3>Coperative Inforamtion</h3>
                 <h3>Press</h3>
        </div>
        <div class="boxs">
          <h2>HELP</h2>
          <h3>Payments</h3>
          <h3>Shipping</h3>
          <h3>Cancellations & Returns</h3>
          <h3>FAQ</h3>
          <h3>Report Infringment</h3>
 </div>
 <div class="boxs">
   <h2>POLICY</h2>
   <h3>Return policy</h3>
   <h3>Terms of use</h3>
   <h3>Security</h3>
   <h3>Privacy</h3>
   <h3>Sitemap</h3>
   <h3>EPR Compilance</h3>
</div>
<div class="boxs">
<h2>SOCIAL</h2>
<h3>Facebook</h3>
<h3>Twitter</h3>
<h3>Youtube</h3>
</div>
<div class="boxs">

<div class="vr">
<h2>Mail Us</h2> 
<h3>happyshopping2002<br>@gmail.com</h3></div> </div>  
<div class="boxs">
<h2>Registered Office Address:</h2>
<h3>B-203 Ganpati Plaza ,Vidhyadhar Nagar,Jaipur</h3>
</div>

</div>
<div class="icon">
<div class="i"><i class="fa-solid fa-suitcase fa-2x"></i>
                 <h5>Become a seller</h5></div>
<div class="i"><i class="fa-sharp fa-solid fa-star fa-2x"></i>
<h5>Advertise</h5></div>
<div class="i"><i class="fa-solid fa-gift fa-2x"></i>
<h5>Gift cards</h5></div>
<div class="i"><i class="fa-solid fa-circle-question fa-2x"></i>
<h5>Help Center</h5></div> 
<div class="pp">
<div class="i"><i class="fa-brands fa-cc-visa fa-2x"></i>
  </div> 
  <div class="i"><i class="fa-sharp fa-solid fa-credit-card fa-2x"></i>
  </div> 

  <div class="i"><i class="fa-solid fa-wallet fa-2x"></i></div>
           
</div>
       
               
    
</body>
</html>