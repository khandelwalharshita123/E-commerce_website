<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Women page</title>
    <style>
              .div{
                           width:100%;
                           height: 1200px;
                          background-color:white;
                     }
                      .box{
                             width:20%;
                             height: 350px;
                             background-color: #454242;
                             margin: 6%;
                             float: left;

                      }
                      .button {
  background-color:black;
  border: none;
  color:white;

  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;

  cursor: pointer;
}
h3{
                font-size: 25px;
                color:black;
           }
           input{
                    width:300px;
                    height:50px;
                    
           }
           img{
                                width:100%;
                             height: 350px;
           }
           h1{
                font-family:cursive;
                font-size: 40px;
                padding-left:40%;
             
           }
       
    </style>
</head>
<body>  <h1>
    WOMEN'S WEAR
</h1>

<hr>
    <div class="div">
      
   <div class="box"><a href="add.html"><img src="wom1.jpg"><h3>Rs.1500 (20% Off)</h3><input type="submit" class="button"value="add to cart"></a></div>
   <div class="box"><a href="add2.html"><img src="wom2.jpg"><h3>Rs.2500 (10% Off)</h3><input type="submit" class="button"value="add to cart"></a></div>
 <div class="box"><a href="add3.html"><img src="wom3.jpg"><h3>Rs.1999 (15% Off)</h3><input type="submit" class="button"value="add to cart"></a></div>
 <div class="box"><a href="add4.html"><img src="wom4.jpg"><h3>Rs.1500 (10% Off)</h3><input type="submit" class="button"value="add to cart"></a></div>
<div class="box"><a href="add5.html"><img src="wom5.jpg"><h3>Rs.1999</h3><input type="submit" class="button"value="add to cart"></a></div>
<div class="box"><a href="add6.html"><img src="wom6.jpg"><h3>Rs.3500 (15% Off)</h3><input type="submit" class="button"value="add to cart"></a></div>
    </div>

</body>
</html>