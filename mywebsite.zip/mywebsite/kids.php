<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>kids page</title>
    <style>
              .div{
                           width:100%;
                           height: 1200px;
                          background-color:white;
                     }
                      .box{
                             width:20%;
                             height: 350px;
                             background-color: #454242;
                             margin: 6%;
                             float: left;

                      }
                      .button {
  background-color:black;
  border: none;
  color:white;

  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;

  cursor: pointer;
}
h3{
                font-size: 25px;
                color:black;
                 
           }
           input{
                    width:300px;
                    height:50px;
                    
           }
           img{
                                width:100%;
                             height: 350px;
           }
           h1{
                font-family:cursive;
                padding-left:40%;
                font-size: 40px;
           }
    </style>
</head>
<body> <h1>
    KID'S WEAR
</h1>

<hr>
    <div class="div">
      
   <div class="box"><a href="add13.html"><img src="kid1.jpg"><h3>Rs.2500 (10% Off)</h3><input type="submit" class="button"value="add to cart"></a></div>
   <div class="box"><a href="add14.html"><img src="kid2.jpg"><h3>Rs.3000 (15% Off)</h3><input type="submit" class="button"value="add to cart"></a></div>
   <div class="box"><a href="add15.html"><img src="kid3.jpg"><h3>Rs.3500 (10% Off)</h3><input type="submit" class="button"value="add to cart"></a></div>
   <div class="box"><a href="add16.html"><img src="kid4.jpg"><h3>Rs.1999(10% Off)</h3><input type="submit" class="button"value="add to cart"></a></div>
   <div class="box"><a href="add17.html"><img src="kid5.jpg"><h3>Rs.2800 (15% Off)</h3><input type="submit" class="button"value="add to cart"></a></div>
   <div class="box"><a href="add18.html"><img src="kid6.jpg"><h3>Rs.3200(10% Off)</h3><input type="submit" class="button"value="add to cart"></a></div>
    </div>

</body>
</html>